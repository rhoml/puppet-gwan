#if !(__GNUC__ || __ICC)

#ifndef _STDBOOL_H
#define _STDBOOL_H

// ISO C99 boolean definitions
# define bool	_Bool
# define true	1
# define false	0

#endif // _STDBOOL_H

#endif

